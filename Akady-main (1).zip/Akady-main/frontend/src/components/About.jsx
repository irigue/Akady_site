import React from 'react';
import { Accessibility, ShoppingBag, Utensils, Leaf, Users, CreditCard, Clock, Smile } from 'lucide-react';

const About = () => {
  return (
    <section id="about" className="section" style={{ backgroundColor: '#ffffff', width: '100%', overflowX: 'hidden' }}>
      <div className="container" style={{ width: '100%' }}>
        <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <h2
            style={{
              fontFamily: 'var(--font-serif)',
              fontSize: 'clamp(1.75rem, 4vw, 3rem)',
              fontWeight: '700',
              color: '#0f172a',
              marginBottom: '1rem'
            }}
          >
            À propos d'AKADY
          </h2>
          <div
            style={{
              width: '80px',
              height: '4px',
              backgroundColor: '#E07856',
              margin: '0 auto',
              borderRadius: '2px'
            }}
          ></div>
        </div>

        {/* Accessibilité & Services */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 250px), 1fr))',
            gap: '1.5rem',
            marginBottom: '2rem',
            width: '100%'
          }}
        >
          <div
            style={{
              backgroundColor: '#FFF8E7',
              padding: '1.5rem',
              borderRadius: '12px',
              boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
              width: '100%'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem', flexWrap: 'wrap' }}>
              <Accessibility size={28} color="#E07856" style={{ flexShrink: 0 }} />
              <h3 style={{ fontSize: 'clamp(1.1rem, 2vw, 1.5rem)', fontWeight: '600', color: '#0f172a' }}>Accessibilité</h3>
            </div>
            <ul style={{ listStyle: 'none', padding: 0, color: '#64748b', lineHeight: '2', fontSize: 'clamp(0.875rem, 1.5vw, 1rem)' }}>
              <li>✓ Entrée accessible en fauteuil roulant</li>
            </ul>
          </div>

          <div
            style={{
              backgroundColor: '#FFF8E7',
              padding: '1.5rem',
              borderRadius: '12px',
              boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
              width: '100%'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem', flexWrap: 'wrap' }}>
              <ShoppingBag size={28} color="#2D5016" style={{ flexShrink: 0 }} />
              <h3 style={{ fontSize: 'clamp(1.1rem, 2vw, 1.5rem)', fontWeight: '600', color: '#0f172a' }}>Services</h3>
            </div>
            <ul style={{ listStyle: 'none', padding: 0, color: '#64748b', lineHeight: '2', fontSize: 'clamp(0.875rem, 1.5vw, 1rem)' }}>
              <li>✓ Vente à emporter</li>
              <li>✓ Repas sur place</li>
              <li>✓ Traiteur</li>
            </ul>
          </div>

          <div
            style={{
              backgroundColor: '#FFF8E7',
              padding: '1.5rem',
              borderRadius: '12px',
              boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
              width: '100%'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem', flexWrap: 'wrap' }}>
              <Utensils size={28} color="#E07856" style={{ flexShrink: 0 }} />
              <h3 style={{ fontSize: 'clamp(1.1rem, 2vw, 1.5rem)', fontWeight: '600', color: '#0f172a' }}>Populaire pour</h3>
            </div>
            <ul style={{ listStyle: 'none', padding: 0, color: '#64748b', lineHeight: '2', fontSize: 'clamp(0.875rem, 1.5vw, 1rem)' }}>
              <li>✓ Déjeuner</li>
              <li>✓ Dîner</li>
              <li>✓ Dîner en solo</li>
            </ul>
          </div>
        </div>

        {/* Offre & Restauration */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 250px), 1fr))',
            gap: '1.5rem',
            marginBottom: '2rem',
            width: '100%'
          }}
        >
          <div
            style={{
              backgroundColor: '#F5E6D3',
              padding: '1.5rem',
              borderRadius: '12px',
              boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
              width: '100%'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem', flexWrap: 'wrap' }}>
              <Leaf size={28} color="#2D5016" style={{ flexShrink: 0 }} />
              <h3 style={{ fontSize: 'clamp(1.1rem, 2vw, 1.5rem)', fontWeight: '600', color: '#0f172a' }}>Notre Offre</h3>
            </div>
            <ul style={{ listStyle: 'none', padding: 0, color: '#64748b', lineHeight: '2', fontSize: 'clamp(0.875rem, 1.5vw, 1rem)' }}>
              <li>✓ Convient aux végétariens</li>
              <li>✓ Petites portions à partager</li>
              <li>✓ Plats halal</li>
              <li>✓ Plats végétaliens</li>
              <li>✓ Produits sains</li>
            </ul>
          </div>

          <div
            style={{
              backgroundColor: '#F5E6D3',
              padding: '1.5rem',
              borderRadius: '12px',
              boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
              width: '100%'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem', flexWrap: 'wrap' }}>
              <Clock size={28} color="#E07856" style={{ flexShrink: 0 }} />
              <h3 style={{ fontSize: 'clamp(1.1rem, 2vw, 1.5rem)', fontWeight: '600', color: '#0f172a' }}>Restauration</h3>
            </div>
            <ul style={{ listStyle: 'none', padding: 0, color: '#64748b', lineHeight: '2', fontSize: 'clamp(0.875rem, 1.5vw, 1rem)' }}>
              <li>✓ Déjeuner</li>
              <li>✓ Dîner</li>
              <li>✓ Traiteur</li>
              <li>✓ Desserts</li>
            </ul>
          </div>

          <div
            style={{
              backgroundColor: '#F5E6D3',
              padding: '1.5rem',
              borderRadius: '12px',
              boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
              width: '100%'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem', flexWrap: 'wrap' }}>
              <Smile size={28} color="#2D5016" style={{ flexShrink: 0 }} />
              <h3 style={{ fontSize: 'clamp(1.1rem, 2vw, 1.5rem)', fontWeight: '600', color: '#0f172a' }}>Ambiance</h3>
            </div>
            <ul style={{ listStyle: 'none', padding: 0, color: '#64748b', lineHeight: '2', fontSize: 'clamp(0.875rem, 1.5vw, 1rem)' }}>
              <li>✓ Ambiance décontractée</li>
              <li>✓ Cadre agréable</li>
              <li>✓ Calme</li>
            </ul>
          </div>
        </div>

        {/* Clientèle & Paiements */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 250px), 1fr))',
            gap: '1.5rem',
            width: '100%'
          }}
        >
          <div
            style={{
              backgroundColor: '#FFF8E7',
              padding: '1.5rem',
              borderRadius: '12px',
              boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
              width: '100%'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem', flexWrap: 'wrap' }}>
              <Users size={28} color="#E07856" style={{ flexShrink: 0 }} />
              <h3 style={{ fontSize: 'clamp(1.1rem, 2vw, 1.5rem)', fontWeight: '600', color: '#0f172a' }}>Clientèle</h3>
            </div>
            <ul style={{ listStyle: 'none', padding: 0, color: '#64748b', lineHeight: '2', fontSize: 'clamp(0.875rem, 1.5vw, 1rem)' }}>
              <li>✓ Adapté aux familles</li>
              <li>✓ Groupes</li>
              <li>✓ Touristes</li>
            </ul>
          </div>

          <div
            style={{
              backgroundColor: '#FFF8E7',
              padding: '1.5rem',
              borderRadius: '12px',
              boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
              width: '100%'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem', flexWrap: 'wrap' }}>
              <CreditCard size={28} color="#2D5016" style={{ flexShrink: 0 }} />
              <h3 style={{ fontSize: 'clamp(1.1rem, 2vw, 1.5rem)', fontWeight: '600', color: '#0f172a' }}>Paiements</h3>
            </div>
            <ul style={{ listStyle: 'none', padding: 0, color: '#64748b', lineHeight: '2', fontSize: 'clamp(0.875rem, 1.5vw, 1rem)' }}>
              <li>✓ Bimpli</li>
              <li>✓ Cartes de crédit/débit</li>
              <li>✓ Chèque Déjeuner</li>
              <li>✓ Ticket Restaurant</li>
              <li>✓ Titres restaurant</li>
            </ul>
          </div>

          <div
            style={{
              backgroundColor: '#FFF8E7',
              padding: '1.5rem',
              borderRadius: '12px',
              boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'center',
              alignItems: 'center',
              textAlign: 'center',
              width: '100%'
            }}
          >
            <Clock size={36} color="#E07856" style={{ marginBottom: '1rem' }} />
            <h3 style={{ fontSize: 'clamp(1.1rem, 2vw, 1.5rem)', fontWeight: '600', color: '#0f172a', marginBottom: '0.5rem' }}>Planning</h3>
            <p style={{ color: '#64748b', fontSize: 'clamp(0.95rem, 1.5vw, 1.1rem)' }}>Réservations acceptées</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;