import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { Link } from 'react-scroll';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { name: 'Accueil', to: 'hero' },
    { name: 'Menu', to: 'menu' },
    { name: 'À propos', to: 'about' },
    { name: 'Galerie', to: 'gallery' },
    { name: 'Contact', to: 'contact' }
  ];

  return (
    <header
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        width: '100%',
        zIndex: 1000,
        backgroundColor: isScrolled ? '#ffffff' : 'rgba(255, 255, 255, 0.95)',
        boxShadow: isScrolled ? '0 2px 10px rgba(0,0,0,0.1)' : 'none',
        transition: 'all 0.3s ease'
      }}
    >
      <nav style={{ maxWidth: '1200px', margin: '0 auto', padding: '0.75rem 1rem', width: '100%' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%' }}>
          {/* Logo */}
          <Link to="hero" smooth duration={500} style={{ cursor: 'pointer', textDecoration: 'none', flexShrink: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <img
                src="https://customer-assets.emergentagent.com/job_resto-inclusif/artifacts/6afdxc8q_logo.png"
                alt="AKADY Logo"
                style={{
                  height: '45px',
                  width: 'auto',
                  objectFit: 'contain',
                  maxWidth: '150px'
                }}
              />
            </div>
          </Link>

          {/* Desktop Navigation */}
          <ul
            style={{
              display: 'none',
              gap: '2rem',
              listStyle: 'none',
              margin: 0,
              padding: 0
            }}
            className="desktop-nav"
          >
            {navItems.map((item) => (
              <li key={item.to}>
                <Link
                  to={item.to}
                  smooth
                  duration={500}
                  offset={-80}
                  style={{
                    color: '#1e293b',
                    fontWeight: '500',
                    cursor: 'pointer',
                    transition: 'color 0.2s ease',
                    textDecoration: 'none',
                    whiteSpace: 'nowrap'
                  }}
                  className="nav-link"
                >
                  {item.name}
                </Link>
              </li>
            ))}
          </ul>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            style={{
              background: 'transparent',
              border: 'none',
              cursor: 'pointer',
              padding: '0.5rem',
              flexShrink: 0
            }}
            className="mobile-menu-btn"
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div
            style={{
              backgroundColor: '#ffffff',
              marginTop: '1rem',
              padding: '1rem',
              borderRadius: '8px',
              boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
            }}
            className="mobile-nav"
          >
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '1rem', margin: 0, padding: 0 }}>
              {navItems.map((item) => (
                <li key={item.to}>
                  <Link
                    to={item.to}
                    smooth
                    duration={500}
                    offset={-80}
                    onClick={() => setIsMobileMenuOpen(false)}
                    style={{
                      color: '#1e293b',
                      fontWeight: '500',
                      cursor: 'pointer',
                      textDecoration: 'none',
                      display: 'block',
                      padding: '0.5rem'
                    }}
                  >
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        )}
      </nav>

      <style>{`
        @media (min-width: 768px) {
          .desktop-nav {
            display: flex !important;
          }
          .mobile-menu-btn {
            display: none;
          }
        }
        .nav-link:hover {
          color: #E07856 !important;
        }
      `}</style>
    </header>
  );
};

export default Header;