import React from 'react';
import { Link } from 'react-scroll';
import { Utensils, Heart, Phone } from 'lucide-react';

const Hero = () => {
  return (
    <section
      id="hero"
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        position: 'relative',
        paddingTop: '80px',
        width: '100%',
        backgroundImage: 'url(https://customer-assets.emergentagent.com/job_resto-inclusif/artifacts/9jd7j2ot_arriere%20plan.jpg)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}
    >
      {/* Overlay */}
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(255, 248, 231, 0.85)',
          zIndex: 1
        }}
      ></div>

      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '2rem 1rem', textAlign: 'center', position: 'relative', zIndex: 2, width: '100%' }}>
        {/* Icon decoration */}
        <div style={{ display: 'flex', justifyContent: 'center', gap: '1rem', marginBottom: '2rem', opacity: 0.7, flexWrap: 'wrap' }}>
          <Utensils size={40} color="#E07856" />
          <Heart size={40} color="#2D5016" />
          <Utensils size={40} color="#E07856" />
        </div>

        {/* Main heading */}
        <h1
          style={{
            fontFamily: 'var(--font-serif)',
            fontSize: 'clamp(2rem, 5vw, 4.5rem)',
            fontWeight: '700',
            color: '#0f172a',
            marginBottom: '1.5rem',
            lineHeight: '1.2',
            wordBreak: 'break-word'
          }}
        >
          Bien manger,
          <br />
          <span style={{ color: '#E07856' }}>c'est aussi partager</span>
        </h1>

        {/* Subtitle */}
        <p
          style={{
            fontSize: 'clamp(1rem, 2vw, 1.5rem)',
            color: '#64748b',
            marginBottom: '1.5rem',
            maxWidth: '800px',
            margin: '0 auto 1.5rem',
            lineHeight: '1.8',
            padding: '0 1rem'
          }}
        >
          AKADY se veut être un restaurant solidaire proposant des plats originaires d'Afrique subsaharienne à des prix modestes.
        </p>

        {/* Prix moyen */}
        <div
          style={{
            display: 'inline-block',
            backgroundColor: '#2D5016',
            color: '#ffffff',
            padding: '0.75rem 1.5rem',
            borderRadius: '50px',
            fontSize: 'clamp(1rem, 2vw, 1.1rem)',
            fontWeight: '600',
            marginBottom: '2rem',
            maxWidth: '90%'
          }}
        >
          10-20 € par personne
        </div>

        {/* CTA Buttons */}
        <div
          style={{
            display: 'flex',
            gap: '1rem',
            justifyContent: 'center',
            flexWrap: 'wrap',
            marginBottom: '3rem',
            padding: '0 1rem'
          }}
        >
          <Link to="menu" smooth duration={500} offset={-80}>
            <button className="btn-primary">Voir le menu</button>
          </Link>
          <Link to="contact" smooth duration={500} offset={-80}>
            <button className="btn-secondary">Réserver une table</button>
          </Link>
        </div>

        {/* Key features */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '2rem',
            marginTop: '4rem',
            maxWidth: '900px',
            margin: '4rem auto 0',
            padding: '0 1rem'
          }}
        >
          <div style={{ textAlign: 'center' }}>
            <div
              style={{
                width: '60px',
                height: '60px',
                backgroundColor: '#E07856',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 1rem',
                boxShadow: '0 4px 6px rgba(224, 120, 86, 0.3)'
              }}
            >
              <Utensils size={28} color="#ffffff" />
            </div>
            <h3 style={{ fontSize: 'clamp(1rem, 2vw, 1.1rem)', fontWeight: '600', marginBottom: '0.5rem', color: '#0f172a' }}>
              Cuisine authentique
            </h3>
            <p style={{ color: '#64748b', fontSize: 'clamp(0.875rem, 1.5vw, 0.95rem)' }}>Saveurs africaines</p>
          </div>

          <div style={{ textAlign: 'center' }}>
            <div
              style={{
                width: '60px',
                height: '60px',
                backgroundColor: '#2D5016',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 1rem',
                boxShadow: '0 4px 6px rgba(45, 80, 22, 0.3)'
              }}
            >
              <Heart size={28} color="#ffffff" />
            </div>
            <h3 style={{ fontSize: 'clamp(1rem, 2vw, 1.1rem)', fontWeight: '600', marginBottom: '0.5rem', color: '#0f172a' }}>
              Prix accessibles
            </h3>
            <p style={{ color: '#64748b', fontSize: 'clamp(0.875rem, 1.5vw, 0.95rem)' }}>À partir de 8,50€</p>
          </div>

          <div style={{ textAlign: 'center' }}>
            <div
              style={{
                width: '60px',
                height: '60px',
                backgroundColor: '#E07856',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 1rem',
                boxShadow: '0 4px 6px rgba(224, 120, 86, 0.3)'
              }}
            >
              <Phone size={28} color="#ffffff" />
            </div>
            <h3 style={{ fontSize: 'clamp(1rem, 2vw, 1.1rem)', fontWeight: '600', marginBottom: '0.5rem', color: '#0f172a' }}>
              Réservations
            </h3>
            <p style={{ color: '#64748b', fontSize: 'clamp(0.875rem, 1.5vw, 0.95rem)' }}>07 53 93 89 00</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;