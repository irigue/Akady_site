import React from 'react';
import { Leaf } from 'lucide-react';

const Menu = () => {
  const menuItems = [
    {
      name: 'Tchieb',
      description: 'Riz rouge accompagné de ses légumes (carottes, chou, pomme de terre)',
      price: '8,5€',
      category: 'Nos Plats',
      vegetarian: false
    },
    {
      name: 'Poulet Aloco',
      description: 'Poulet braisé accompagné de bananes plantains frites',
      price: '9,5€',
      category: 'Nos Plats',
      vegetarian: false
    },
    {
      name: 'Yassa',
      description: 'Sauce à base d\'oignons frits accompagnée de son riz et de son poulet',
      price: '8,5€',
      category: 'Nos Plats',
      vegetarian: false
    },
    {
      name: 'Mafé',
      description: 'Sauce à base de pâte d\'arachide accompagnée de bœuf ou cuisse de poulet',
      price: '8,5€',
      category: 'Nos Plats',
      vegetarian: false
    },
    {
      name: 'Couscous',
      description: 'Semoule de blé accompagnée de légumes et de son poulet',
      price: '8,5€',
      category: 'Nos Plats',
      vegetarian: false
    },
    {
      name: 'Sauce Graine',
      description: 'Sauce rouge préparée à partir de la pulpe du fruit du palmier accompagnée de riz',
      price: '8,5€',
      category: 'Autres Plats / Sauces',
      vegetarian: false
    },
    {
      name: 'Sauce Épinard',
      description: 'Sauce à base d\'épinard accompagnée de son riz blanc',
      price: '8,5€',
      category: 'Autres Plats / Sauces',
      vegetarian: true
    },
    {
      name: 'Attiéké',
      description: 'Semoule de manioc accompagnée de ses condiments et son poisson (chinchard ou tilapia)',
      price: '9,5€ / 13€',
      category: 'Autres Plats / Sauces',
      vegetarian: false
    },
    {
      name: 'Placali',
      description: 'Pâte de manioc fermentée d\'origine ivoirienne dégustée avec sauce graine ou Kopè',
      price: '13€',
      category: 'Autres Plats / Sauces',
      vegetarian: false
    },
    {
      name: 'Nos Jus',
      description: 'Bissap, Gingembre, Tamarin, Baobab…',
      price: '',
      category: 'Boissons & Desserts',
      vegetarian: true
    },
    {
      name: 'Nos Desserts',
      description: 'Thiakhry, Bofloto…',
      price: '',
      category: 'Boissons & Desserts',
      vegetarian: true
    }
  ];

  const categories = ['Nos Plats', 'Autres Plats / Sauces', 'Boissons & Desserts'];

  return (
    <section id="menu" className="section" style={{ backgroundColor: '#FFF8E7', width: '100%', overflowX: 'hidden' }}>
      <div className="container" style={{ width: '100%' }}>
        <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <h2
            style={{
              fontFamily: 'var(--font-serif)',
              fontSize: 'clamp(1.75rem, 4vw, 3rem)',
              fontWeight: '700',
              color: '#0f172a',
              marginBottom: '1rem'
            }}
          >
            Notre Menu
          </h2>
          <div
            style={{
              width: '80px',
              height: '4px',
              backgroundColor: '#E07856',
              margin: '0 auto 1.5rem',
              borderRadius: '2px'
            }}
          ></div>
          <p style={{ color: '#64748b', fontSize: 'clamp(1rem, 2vw, 1.1rem)', maxWidth: '700px', margin: '0 auto', padding: '0 1rem' }}>
            Découvrez nos plats savoureux inspirés de la cuisine africaine et locale, préparés avec soin et passion.
          </p>
        </div>

        {categories.map((category) => {
          const categoryItems = menuItems.filter((item) => item.category === category);
          if (categoryItems.length === 0) return null;

          return (
            <div key={category} style={{ marginBottom: '3rem', width: '100%' }}>
              <h3
                style={{
                  fontSize: 'clamp(1.25rem, 3vw, 1.8rem)',
                  fontWeight: '600',
                  color: '#2D5016',
                  marginBottom: '1.5rem',
                  paddingBottom: '0.5rem',
                  borderBottom: '2px solid #E07856',
                  wordBreak: 'break-word'
                }}
              >
                {category}
              </h3>
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fill, minmax(min(100%, 280px), 1fr))',
                  gap: '1.5rem',
                  width: '100%'
                }}
              >
                {categoryItems.map((item, index) => (
                  <div
                    key={index}
                    style={{
                      backgroundColor: '#ffffff',
                      borderRadius: '12px',
                      overflow: 'hidden',
                      boxShadow: '0 4px 6px rgba(0,0,0,0.08)',
                      transition: 'transform 0.3s ease, box-shadow 0.3s ease',
                      width: '100%'
                    }}
                    className="menu-card"
                  >
                    <div style={{ padding: '1.5rem' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '1rem', gap: '0.5rem' }}>
                        <h4
                          style={{
                            fontSize: 'clamp(1.1rem, 2vw, 1.3rem)',
                            fontWeight: '600',
                            color: '#0f172a',
                            flex: 1,
                            wordBreak: 'break-word'
                          }}
                        >
                          {item.name}
                        </h4>
                        {item.vegetarian && (
                          <div
                            style={{
                              backgroundColor: '#2D5016',
                              borderRadius: '50%',
                              width: '32px',
                              height: '32px',
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'center',
                              flexShrink: 0
                            }}
                            title="Végétarien"
                          >
                            <Leaf size={18} color="#ffffff" />
                          </div>
                        )}
                      </div>
                      <p style={{ color: '#64748b', marginBottom: '1.5rem', lineHeight: '1.6', fontSize: 'clamp(0.875rem, 1.5vw, 1rem)' }}>
                        {item.description}
                      </p>
                      {item.price && (
                        <div
                          style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center'
                          }}
                        >
                          <span
                            style={{
                              fontSize: 'clamp(1.25rem, 2.5vw, 1.5rem)',
                              fontWeight: '700',
                              color: '#E07856'
                            }}
                          >
                            {item.price}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}

        {/* Info box */}
        <div
          style={{
            backgroundColor: '#F5E6D3',
            padding: '1.5rem',
            borderRadius: '12px',
            marginTop: '3rem',
            textAlign: 'center',
            width: '100%'
          }}
        >
          <p style={{ color: '#2D5016', fontSize: 'clamp(0.875rem, 1.5vw, 1rem)', lineHeight: '1.8', marginBottom: '1rem' }}>
            <strong>Options disponibles :</strong> Halal • Végétarien • Végétalien • Sans gluten (sur demande)
          </p>
          <p style={{ color: '#64748b', fontSize: 'clamp(0.875rem, 1.5vw, 0.95rem)' }}>
            Nos prix solidaires permettent à tous de profiter d'une cuisine de qualité. Une partie des bénéfices
            soutient nos actions sociales.
          </p>
        </div>
      </div>

      <style>{`
        .menu-card:hover {
          transform: translateY(-4px);
          box-shadow: 0 8px 16px rgba(0,0,0,0.12);
        }
        @media (max-width: 767px) {
          .menu-card {
            transform: none !important;
          }
        }
      `}</style>
    </section>
  );
};

export default Menu;