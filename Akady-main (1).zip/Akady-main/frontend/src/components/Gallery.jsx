import React from 'react';

const Gallery = () => {
  const galleryGroups = [
    {
      title: 'Bienvenue chez AKADY',
      images: [
        {
          url: 'https://customer-assets.emergentagent.com/job_resto-inclusif/artifacts/m4xp730h_1.jpg',
          alt: 'Plats du jour AKADY'
        },
        {
          url: 'https://customer-assets.emergentagent.com/job_resto-inclusif/artifacts/1tjlhina_2.jpg',
          alt: 'Menu AKADY'
        },
        {
          url: 'https://customer-assets.emergentagent.com/job_resto-inclusif/artifacts/7p45wxdq_3.jpg',
          alt: 'Menu extérieur'
        },
        {
          url: 'https://customer-assets.emergentagent.com/job_resto-inclusif/artifacts/j8mwbu44_4.jpeg',
          alt: 'Nos plats'
        },
        {
          url: 'https://customer-assets.emergentagent.com/job_resto-inclusif/artifacts/dx08c517_5.jpg',
          alt: 'Restaurant solidaire'
        },
        {
          url: 'https://customer-assets.emergentagent.com/job_resto-inclusif/artifacts/2ep4o4y0_6.jpg',
          alt: 'Ambiance AKADY'
        }
      ]
    },
    {
      title: 'Meilleures offres',
      images: [
        {
          url: 'https://customer-assets.emergentagent.com/job_resto-inclusif/artifacts/e3oxkta9_7.jpeg',
          alt: 'Offre spéciale 1'
        },
        {
          url: 'https://customer-assets.emergentagent.com/job_resto-inclusif/artifacts/z4fi8kjd_8.jpeg',
          alt: 'Offre spéciale 2'
        },
        {
          url: 'https://customer-assets.emergentagent.com/job_resto-inclusif/artifacts/4t3ezqz9_9.jpg',
          alt: 'Offre spéciale 3'
        },
        {
          url: 'https://customer-assets.emergentagent.com/job_resto-inclusif/artifacts/rellenty_10.jpg',
          alt: 'Offre spéciale 4'
        },
        {
          url: 'https://customer-assets.emergentagent.com/job_resto-inclusif/artifacts/zzug428m_11.jpg',
          alt: 'Offre spéciale 5'
        },
        {
          url: 'https://customer-assets.emergentagent.com/job_resto-inclusif/artifacts/7xj8yfat_12.jpg',
          alt: 'Offre spéciale 6'
        },
        {
          url: 'https://customer-assets.emergentagent.com/job_resto-inclusif/artifacts/c22hhfvn_13.jpeg',
          alt: 'Offre spéciale 7'
        },
        {
          url: 'https://customer-assets.emergentagent.com/job_resto-inclusif/artifacts/ukeii5qi_14.jpg',
          alt: 'Offre spéciale 8'
        }
      ]
    }
  ];

  return (
    <section id="gallery" className="section" style={{ backgroundColor: '#FFF8E7', width: '100%', overflowX: 'hidden' }}>
      <div className="container" style={{ width: '100%' }}>
        <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <h2
            style={{
              fontFamily: 'var(--font-serif)',
              fontSize: 'clamp(1.75rem, 4vw, 3rem)',
              fontWeight: '700',
              color: '#0f172a',
              marginBottom: '1rem'
            }}
          >
            Galerie
          </h2>
          <div
            style={{
              width: '80px',
              height: '4px',
              backgroundColor: '#E07856',
              margin: '0 auto 1.5rem',
              borderRadius: '2px'
            }}
          ></div>
          <p style={{ color: '#64748b', fontSize: 'clamp(1rem, 2vw, 1.1rem)', maxWidth: '700px', margin: '0 auto', padding: '0 1rem' }}>
            Découvrez nos plats savoureux et l'ambiance chaleureuse de notre restaurant solidaire.
          </p>
        </div>

        {galleryGroups.map((group, groupIndex) => (
          <div key={groupIndex} style={{ marginBottom: '4rem', width: '100%' }}>
            <h3
              style={{
                fontSize: 'clamp(1.5rem, 3vw, 2rem)',
                fontWeight: '600',
                color: '#2D5016',
                marginBottom: '2rem',
                textAlign: 'center',
                paddingBottom: '1rem',
                borderBottom: '2px solid #E07856',
                maxWidth: '600px',
                margin: '0 auto 2rem'
              }}
            >
              {group.title}
            </h3>
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 250px), 1fr))',
                gap: '1.5rem',
                width: '100%'
              }}
            >
              {group.images.map((image, index) => (
                <div
                  key={index}
                  style={{
                    position: 'relative',
                    borderRadius: '12px',
                    overflow: 'hidden',
                    boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                    transition: 'transform 0.3s ease, box-shadow 0.3s ease',
                    cursor: 'pointer',
                    backgroundColor: '#ffffff',
                    width: '100%'
                  }}
                  className="gallery-item"
                >
                  <div
                    style={{
                      width: '100%',
                      paddingTop: '75%',
                      position: 'relative',
                      overflow: 'hidden'
                    }}
                  >
                    <img
                      src={image.url}
                      alt={image.alt}
                      style={{
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        width: '100%',
                        height: '100%',
                        objectFit: 'cover',
                        transition: 'transform 0.3s ease'
                      }}
                      className="gallery-img"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}

        {/* CTA */}
        <div
          style={{
            marginTop: '3rem',
            textAlign: 'center',
            backgroundColor: '#F5E6D3',
            padding: '2rem 1rem',
            borderRadius: '12px',
            width: '100%'
          }}
        >
          <h3
            style={{
              fontSize: 'clamp(1.25rem, 3vw, 1.8rem)',
              fontWeight: '600',
              color: '#2D5016',
              marginBottom: '1rem'
            }}
          >
            Venez vivre l'expérience AKADY
          </h3>
          <p style={{ color: '#64748b', fontSize: 'clamp(1rem, 2vw, 1.1rem)', marginBottom: '2rem', maxWidth: '600px', margin: '0 auto 2rem', padding: '0 1rem' }}>
            Un repas délicieux dans une ambiance conviviale et solidaire vous attend !
          </p>
        </div>
      </div>

      <style>{`
        .gallery-item:hover {
          transform: translateY(-8px);
          box-shadow: 0 12px 24px rgba(0,0,0,0.15);
        }
        .gallery-item:hover .gallery-img {
          transform: scale(1.05);
        }
        @media (max-width: 767px) {
          .gallery-item:hover {
            transform: translateY(-4px);
          }
        }
      `}</style>
    </section>
  );
};

export default Gallery;