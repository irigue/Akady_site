import React from 'react';
import { Facebook, Instagram, Mail, Phone, MapPin, Heart } from 'lucide-react';
import { Link } from 'react-scroll';

const Footer = () => {
  return (
    <footer style={{ backgroundColor: '#0f172a', color: '#ffffff', paddingTop: '4rem', paddingBottom: '2rem' }}>
      <div className="container">
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
            gap: '3rem',
            marginBottom: '3rem'
          }}
        >
          {/* About */}
          <div>
            <img
              src="https://customer-assets.emergentagent.com/job_resto-inclusif/artifacts/6afdxc8q_logo.png"
              alt="AKADY Logo"
              style={{
                height: '60px',
                width: 'auto',
                marginBottom: '1rem',
                maxWidth: '100%'
              }}
            />
            <p style={{ color: '#94a3b8', lineHeight: '1.7', marginBottom: '1.5rem' }}>
              Restaurant solidaire à Rennes. Une cuisine savoureuse et accessible pour tous, dans un esprit de partage
              et d'entraide.
            </p>
            <div style={{ display: 'flex', gap: '1rem' }}>
              <a
                href="https://www.facebook.com/AKADY.RENNES"
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  width: '40px',
                  height: '40px',
                  backgroundColor: '#1e293b',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  transition: 'background-color 0.2s ease'
                }}
                className="social-link"
                aria-label="Facebook"
              >
                <Facebook size={20} />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  width: '40px',
                  height: '40px',
                  backgroundColor: '#1e293b',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  transition: 'background-color 0.2s ease'
                }}
                className="social-link"
                aria-label="Instagram"
              >
                <Instagram size={20} />
              </a>
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h4 style={{ fontSize: '1.2rem', fontWeight: '600', marginBottom: '1.5rem', color: '#ffffff' }}>
              Navigation
            </h4>
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {['Accueil', 'Menu', 'À propos', 'Galerie', 'Contact'].map((item) => (
                <li key={item}>
                  <Link
                    to={item === 'Accueil' ? 'hero' : item === 'À propos' ? 'about' : item.toLowerCase()}
                    smooth
                    duration={500}
                    offset={-80}
                    style={{
                      color: '#94a3b8',
                      textDecoration: 'none',
                      cursor: 'pointer',
                      transition: 'color 0.2s ease'
                    }}
                    className="footer-link"
                  >
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 style={{ fontSize: '1.2rem', fontWeight: '600', marginBottom: '1.5rem', color: '#ffffff' }}>
              Contact
            </h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div style={{ display: 'flex', alignItems: 'start', gap: '0.75rem' }}>
                <MapPin size={20} color="#E07856" style={{ flexShrink: 0, marginTop: '0.2rem' }} />
                <span style={{ color: '#94a3b8', lineHeight: '1.6' }}>
                  12 Rue de l'Alma
                  <br />
                  35000 Rennes, France
                </span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                <Phone size={20} color="#E07856" style={{ flexShrink: 0 }} />
                <a
                  href="tel:0955404268"
                  style={{
                    color: '#94a3b8',
                    textDecoration: 'none',
                    transition: 'color 0.2s ease'
                  }}
                  className="footer-link"
                >
                  09 55 40 42 68
                </a>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                <Mail size={20} color="#E07856" style={{ flexShrink: 0 }} />
                <a
                  href="mailto:akady.bretagne@gmail.com"
                  style={{
                    color: '#94a3b8',
                    textDecoration: 'none',
                    transition: 'color 0.2s ease',
                    fontSize: '0.9rem'
                  }}
                  className="footer-link"
                >
                  akady.bretagne@gmail.com
                </a>
              </div>
            </div>
          </div>

          {/* Horaires */}
          <div>
            <h4 style={{ fontSize: '1.2rem', fontWeight: '600', marginBottom: '1.5rem', color: '#ffffff' }}>
              Horaires
            </h4>
            <div style={{ color: '#94a3b8', lineHeight: '1.8', fontSize: '0.95rem' }}>
              <p style={{ marginBottom: '0.5rem' }}>
                <strong style={{ color: '#ffffff' }}>Lun-Sam</strong> : 12h-14h45, 18h-22h
              </p>
              <p>
                <strong style={{ color: '#ffffff' }}>Dimanche</strong> : 12h-20h
              </p>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div
          style={{
            borderTop: '1px solid #1e293b',
            paddingTop: '2rem',
            textAlign: 'center'
          }}
        >
          <p style={{ color: '#64748b', fontSize: '0.95rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
            <span>© {new Date().getFullYear()} AKADY Restaurant Solidaire. Tous droits réservés.</span>
            <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
              Fait avec <Heart size={16} color="#E07856" fill="#E07856" /> à Rennes
            </span>
          </p>
        </div>
      </div>

      <style>{`
        .social-link:hover {
          background-color: #E07856 !important;
        }
        .footer-link:hover {
          color: #E07856 !important;
        }
      `}</style>
    </footer>
  );
};

export default Footer;