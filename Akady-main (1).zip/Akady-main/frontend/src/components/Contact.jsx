import React from 'react';
import { MapPin, Phone, Clock, Mail, Calendar } from 'lucide-react';

const Contact = () => {
  const schedule = [
    { day: 'Lundi - Mardi', hours: '12h00-14h45, 18h00-22h00' },
    { day: 'Mercredi', hours: '12h00-14h45, 18h00-22h00' },
    { day: 'Jeudi', hours: '12h00-14h45, 18h00-22h00' },
    { day: 'Vendredi - Samedi', hours: '12h00-14h45, 18h00-22h00' },
    { day: 'Dimanche', hours: '12h00-20h00' }
  ];

  return (
    <section id="contact" className="section" style={{ backgroundColor: '#ffffff', width: '100%', overflowX: 'hidden' }}>
      <div className="container" style={{ width: '100%' }}>
        <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <h2
            style={{
              fontFamily: 'var(--font-serif)',
              fontSize: 'clamp(1.75rem, 4vw, 3rem)',
              fontWeight: '700',
              color: '#0f172a',
              marginBottom: '1rem'
            }}
          >
            Contactez-nous
          </h2>
          <div
            style={{
              width: '80px',
              height: '4px',
              backgroundColor: '#E07856',
              margin: '0 auto 1.5rem',
              borderRadius: '2px'
            }}
          ></div>
          <p style={{ color: '#64748b', fontSize: 'clamp(1rem, 2vw, 1.1rem)', maxWidth: '700px', margin: '0 auto', padding: '0 1rem' }}>
            Une question, une suggestion ou envie de réserver une table ? N'hésitez pas à nous contacter !
          </p>
        </div>

        {/* Réservations Box */}
        <div
          style={{
            backgroundColor: '#E07856',
            padding: '2rem 1rem',
            borderRadius: '12px',
            marginBottom: '3rem',
            textAlign: 'center',
            boxShadow: '0 4px 12px rgba(224, 120, 86, 0.3)',
            width: '100%'
          }}
        >
          <Calendar size={40} color="#ffffff" style={{ margin: '0 auto 1rem' }} />
          <h3 style={{ fontSize: 'clamp(1.5rem, 3vw, 2rem)', fontWeight: '700', color: '#ffffff', marginBottom: '1rem' }}>
            Réservez votre table
          </h3>
          <p style={{ fontSize: 'clamp(1rem, 2vw, 1.2rem)', color: '#ffffff', marginBottom: '1.5rem', padding: '0 0.5rem' }}>
            Pour réserver une table, appelez-nous au
          </p>
          <a
            href="tel:0753938900"
            style={{
              display: 'inline-block',
              backgroundColor: '#ffffff',
              color: '#E07856',
              padding: 'clamp(0.75rem, 2vw, 1rem) clamp(1.5rem, 4vw, 3rem)',
              borderRadius: '8px',
              fontSize: 'clamp(1.25rem, 3vw, 1.8rem)',
              fontWeight: '700',
              textDecoration: 'none',
              transition: 'transform 0.2s ease, box-shadow 0.2s ease',
              boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
              maxWidth: '100%',
              wordBreak: 'break-word'
            }}
            className="phone-reservation"
          >
            07 53 93 89 00
          </a>
        </div>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 280px), 1fr))',
            gap: '2rem',
            marginBottom: '3rem',
            width: '100%'
          }}
        >
          {/* Contact Info */}
          <div style={{ width: '100%' }}>
            <h3
              style={{
                fontSize: 'clamp(1.25rem, 3vw, 1.8rem)',
                fontWeight: '600',
                color: '#2D5016',
                marginBottom: '1.5rem'
              }}
            >
              Informations pratiques
            </h3>

            {/* Adresse */}
            <div style={{ display: 'flex', gap: '1rem', marginBottom: '1.5rem' }}>
              <div
                style={{
                  width: '40px',
                  height: '40px',
                  backgroundColor: '#E07856',
                  borderRadius: '8px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0
                }}
              >
                <MapPin size={20} color="#ffffff" />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <h4 style={{ fontWeight: '600', color: '#0f172a', marginBottom: '0.5rem', fontSize: 'clamp(1rem, 2vw, 1.1rem)' }}>Adresse</h4>
                <p style={{ color: '#64748b', lineHeight: '1.6', fontSize: 'clamp(0.875rem, 1.5vw, 1rem)' }}>
                  12 Rue de l'Alma
                  <br />
                  35000 Rennes, France
                </p>
              </div>
            </div>

            {/* Téléphone */}
            <div style={{ display: 'flex', gap: '1rem', marginBottom: '1.5rem' }}>
              <div
                style={{
                  width: '40px',
                  height: '40px',
                  backgroundColor: '#2D5016',
                  borderRadius: '8px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0
                }}
              >
                <Phone size={20} color="#ffffff" />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <h4 style={{ fontWeight: '600', color: '#0f172a', marginBottom: '0.5rem', fontSize: 'clamp(1rem, 2vw, 1.1rem)' }}>Téléphone</h4>
                <a
                  href="tel:0955404268"
                  style={{
                    color: '#E07856',
                    textDecoration: 'none',
                    fontWeight: '500',
                    transition: 'color 0.2s ease',
                    display: 'block',
                    fontSize: 'clamp(0.875rem, 1.5vw, 1rem)',
                    wordBreak: 'break-word'
                  }}
                  className="phone-link"
                >
                  09 55 40 42 68
                </a>
              </div>
            </div>

            {/* Email */}
            <div style={{ display: 'flex', gap: '1rem', marginBottom: '1.5rem' }}>
              <div
                style={{
                  width: '40px',
                  height: '40px',
                  backgroundColor: '#E07856',
                  borderRadius: '8px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0
                }}
              >
                <Mail size={20} color="#ffffff" />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <h4 style={{ fontWeight: '600', color: '#0f172a', marginBottom: '0.5rem', fontSize: 'clamp(1rem, 2vw, 1.1rem)' }}>Email</h4>
                <a
                  href="mailto:akady.bretagne@gmail.com"
                  style={{
                    color: '#E07856',
                    textDecoration: 'none',
                    fontWeight: '500',
                    transition: 'color 0.2s ease',
                    wordBreak: 'break-word',
                    fontSize: 'clamp(0.875rem, 1.5vw, 1rem)',
                    display: 'block'
                  }}
                  className="phone-link"
                >
                  akady.bretagne@gmail.com
                </a>
              </div>
            </div>

            {/* Horaires */}
            <div style={{ display: 'flex', gap: '1rem', marginBottom: '1.5rem' }}>
              <div
                style={{
                  width: '40px',
                  height: '40px',
                  backgroundColor: '#2D5016',
                  borderRadius: '8px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0
                }}
              >
                <Clock size={20} color="#ffffff" />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <h4 style={{ fontWeight: '600', color: '#0f172a', marginBottom: '1rem', fontSize: 'clamp(1rem, 2vw, 1.1rem)' }}>Horaires d'ouverture</h4>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                  {schedule.map((slot, index) => (
                    <div
                      key={index}
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        color: '#64748b',
                        fontSize: 'clamp(0.8rem, 1.5vw, 0.95rem)',
                        gap: '0.5rem',
                        flexWrap: 'wrap',
                        fontSize: '0.95rem',
                        padding: '0.5rem 0',
                        borderBottom: index < schedule.length - 1 ? '1px solid #f0f0f0' : 'none'
                      }}
                    >
                      <span style={{ fontWeight: '500' }}>{slot.day}</span>
                      <span>{slot.hours}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Google Maps */}
        <div
          style={{
            borderRadius: '12px',
            overflow: 'hidden',
            boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
            height: '400px'
          }}
        >
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2665.7266841644436!2d-1.6847894!3d48.1075569!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x480ede3d09d5e58d%3A0x3e5b7d9f8d3e8b9c!2s12%20Rue%20de%20l'Alma%2C%2035000%20Rennes!5e0!3m2!1sfr!2sfr!4v1234567890123!5m2!1sfr!2sfr"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen=""
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title="Localisation AKADY Restaurant"
          ></iframe>
        </div>
      </div>

      <style>{`
        .form-input:focus {
          outline: none;
          border-color: #E07856;
        }
        .phone-link:hover {
          color: #C86442;
        }
        .phone-reservation:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 12px rgba(0,0,0,0.15);
        }
      `}</style>
    </section>
  );
};

export default Contact;