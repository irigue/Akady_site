import React from 'react';
import { HandHeart, Users, Coins, TrendingUp } from 'lucide-react';
import { Link } from 'react-scroll';

const Solidarity = () => {
  return (
    <section id="solidarity" className="section" style={{ backgroundColor: '#ffffff' }}>
      <div className="container">
        <div style={{ textAlign: 'center', marginBottom: '4rem' }}>
          <h2
            style={{
              fontFamily: 'var(--font-serif)',
              fontSize: 'clamp(2rem, 4vw, 3rem)',
              fontWeight: '700',
              color: '#0f172a',
              marginBottom: '1rem'
            }}
          >
            Notre Action Solidaire
          </h2>
          <div
            style={{
              width: '80px',
              height: '4px',
              backgroundColor: '#E07856',
              margin: '0 auto 1.5rem',
              borderRadius: '2px'
            }}
          ></div>
          <p style={{ color: '#64748b', fontSize: '1.1rem', maxWidth: '800px', margin: '0 auto' }}>
            AKADY, c'est bien plus qu'un restaurant. C'est un projet qui place l'humain au cœur de son action et qui
            fait de chaque repas un geste solidaire.
          </p>
        </div>

        {/* Comment ça fonctionne */}
        <div style={{ marginBottom: '5rem' }}>
          <h3
            style={{
              fontSize: '2rem',
              fontWeight: '600',
              color: '#2D5016',
              marginBottom: '3rem',
              textAlign: 'center'
            }}
          >
            Comment fonctionne notre modèle solidaire ?
          </h3>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
              gap: '2rem'
            }}
          >
            <div style={{ textAlign: 'center' }}>
              <div
                style={{
                  width: '80px',
                  height: '80px',
                  backgroundColor: '#E07856',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 1.5rem',
                  boxShadow: '0 4px 8px rgba(224, 120, 86, 0.3)'
                }}
              >
                <Coins size={36} color="#ffffff" />
              </div>
              <h4 style={{ fontSize: '1.2rem', fontWeight: '600', marginBottom: '1rem', color: '#0f172a' }}>
                Prix libre et conscient
              </h4>
              <p style={{ color: '#64748b', lineHeight: '1.7' }}>
                Chacun paie selon ses moyens. Un prix suggéré est indiqué, mais personne n'est refusé faute d'argent.
              </p>
            </div>

            <div style={{ textAlign: 'center' }}>
              <div
                style={{
                  width: '80px',
                  height: '80px',
                  backgroundColor: '#2D5016',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 1.5rem',
                  boxShadow: '0 4px 8px rgba(45, 80, 22, 0.3)'
                }}
              >
                <Users size={36} color="#ffffff" />
              </div>
              <h4 style={{ fontSize: '1.2rem', fontWeight: '600', marginBottom: '1rem', color: '#0f172a' }}>
                Ouvert à tous
              </h4>
              <p style={{ color: '#64748b', lineHeight: '1.7' }}>
                Étudiants, familles, personnes en difficulté... Tout le monde est le bienvenu dans un espace sans
                jugement.
              </p>
            </div>

            <div style={{ textAlign: 'center' }}>
              <div
                style={{
                  width: '80px',
                  height: '80px',
                  backgroundColor: '#E07856',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 1.5rem',
                  boxShadow: '0 4px 8px rgba(224, 120, 86, 0.3)'
                }}
              >
                <HandHeart size={36} color="#ffffff" />
              </div>
              <h4 style={{ fontSize: '1.2rem', fontWeight: '600', marginBottom: '1rem', color: '#0f172a' }}>
                Impact local
              </h4>
              <p style={{ color: '#64748b', lineHeight: '1.7' }}>
                Une partie des recettes finance des actions sociales pour les plus vulnérables de Rennes.
              </p>
            </div>
          </div>
        </div>

        {/* Qui est aidé */}
        <div
          style={{
            backgroundColor: '#FFF8E7',
            padding: '3rem 2rem',
            borderRadius: '12px',
            marginBottom: '3rem'
          }}
        >
          <h3
            style={{
              fontSize: '1.8rem',
              fontWeight: '600',
              color: '#2D5016',
              marginBottom: '2rem',
              textAlign: 'center'
            }}
          >
            Qui aidons-nous ?
          </h3>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
              gap: '1.5rem'
            }}
          >
            {[
              'Étudiants en précarité',
              'Familles monoparentales',
              'Personnes sans-abri',
              'Demandeurs d\'asile',
              'Seniors isolés',
              'Travailleurs précaires'
            ].map((group) => (
              <div
                key={group}
                style={{
                  backgroundColor: '#ffffff',
                  padding: '1.5rem',
                  borderRadius: '8px',
                  textAlign: 'center',
                  boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
                  transition: 'transform 0.2s ease'
                }}
                className="help-card"
              >
                <p style={{ color: '#0f172a', fontWeight: '500' }}>{group}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Comment nous soutenir */}
        <div style={{ textAlign: 'center' }}>
          <h3
            style={{
              fontSize: '2rem',
              fontWeight: '600',
              color: '#2D5016',
              marginBottom: '2rem'
            }}
          >
            Comment nous soutenir ?
          </h3>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
              gap: '2rem',
              maxWidth: '1000px',
              margin: '0 auto 3rem'
            }}
          >
            <div
              style={{
                backgroundColor: '#F5E6D3',
                padding: '2rem',
                borderRadius: '12px',
                textAlign: 'left'
              }}
            >
              <TrendingUp size={32} color="#E07856" style={{ marginBottom: '1rem' }} />
              <h4 style={{ fontSize: '1.3rem', fontWeight: '600', marginBottom: '1rem', color: '#0f172a' }}>
                Venez manger chez nous
              </h4>
              <p style={{ color: '#64748b', lineHeight: '1.7' }}>
                Chaque repas pris au restaurant contribue directement à notre action solidaire.
              </p>
            </div>

            <div
              style={{
                backgroundColor: '#F5E6D3',
                padding: '2rem',
                borderRadius: '12px',
                textAlign: 'left'
              }}
            >
              <HandHeart size={32} color="#2D5016" style={{ marginBottom: '1rem' }} />
              <h4 style={{ fontSize: '1.3rem', fontWeight: '600', marginBottom: '1rem', color: '#0f172a' }}>
                Faites un don
              </h4>
              <p style={{ color: '#64748b', lineHeight: '1.7' }}>
                Votre générosité permet de nourrir davantage de personnes et de financer nos projets.
              </p>
            </div>

            <div
              style={{
                backgroundColor: '#F5E6D3',
                padding: '2rem',
                borderRadius: '12px',
                textAlign: 'left'
              }}
            >
              <Users size={32} color="#E07856" style={{ marginBottom: '1rem' }} />
              <h4 style={{ fontSize: '1.3rem', fontWeight: '600', marginBottom: '1rem', color: '#0f172a' }}>
                Devenez bénévole
              </h4>
              <p style={{ color: '#64748b', lineHeight: '1.7' }}>
                Rejoignez notre équipe de bénévoles et participez à cette belle aventure humaine.
              </p>
            </div>
          </div>

          <Link to="contact" smooth duration={500} offset={-80}>
            <button className="btn-primary" style={{ fontSize: '1.1rem', padding: '14px 40px' }}>
              Nous contacter pour aider
            </button>
          </Link>
        </div>
      </div>

      <style>{`
        .help-card:hover {
          transform: scale(1.05);
        }
      `}</style>
    </section>
  );
};

export default Solidarity;