# Site Web AKADY - Restaurant Solidaire

## 📋 Description du Projet

Site web moderne et responsive pour **AKADY - Restaurant Solidaire**, situé à Rennes. Le site présente le restaurant, sa mission solidaire, ses menus et son impact social dans la communauté rennaise.

## 🎨 Design & Identité Visuelle

### Palette de Couleurs
- **Orange primaire**: #E07856 (couleur signature AKADY)
- **Vert foncé**: #2D5016 (secondaire)
- **Beige clair**: #F5E6D3 (arrière-plans)
- **Crème**: #FFF8E7 (arrière-plans alternatifs)
- **Noir**: #0f172a (textes et boutons)

### Typographie
- **Titres**: Crimson Text (serif) - pour une élégance naturelle
- **Corps de texte**: Sans-serif (système) - pour la lisibilité

## 🏗️ Structure du Site

### 1. **Page d'accueil (Hero)**
- Slogan fort: "Bien manger, c'est aussi partager"
- Présentation courte d'AKADY
- Boutons CTA: "Voir le menu" et "Nous soutenir"
- 3 valeurs clés avec icônes

### 2. **À propos**
- Histoire du restaurant
- Mission solidaire
- Engagement local à Rennes
- Badge des valeurs (Accessibilité, Entraide, Partage, etc.)

### 3. **Menu**
- Catégories: Entrées, Plats principaux, Accompagnements, Desserts
- Plats africains authentiques (Thieb, Mafé, Poulet Braisé, Aloko, etc.)
- Prix solidaires (5-9€)
- Icônes végétariennes
- Options: Halal, Végétarien, Végétalien

### 4. **Action Solidaire**
- Explication du modèle solidaire (prix libre et conscient)
- Qui est aidé (étudiants, familles, personnes sans-abri, etc.)
- Comment soutenir (repas, dons, bénévolat)

### 5. **Galerie**
- 5 photos réelles du restaurant et des plats
- Présentation visuelle de l'ambiance

### 6. **Contact**
- Formulaire de contact fonctionnel
- Informations pratiques:
  - **Adresse**: 12 Rue de l'Alma, 35000 Rennes
  - **Téléphone**: 09 55 40 42 68
  - **Horaires**: Lun-Sam 12h-14h45, 18h-22h | Dim 12h-20h
- Carte Google Maps intégrée

### 7. **Footer**
- Navigation rapide
- Coordonnées
- Réseaux sociaux
- Copyright

## ✨ Fonctionnalités

### Navigation
- ✅ Menu de navigation fixe avec smooth scroll
- ✅ Navigation responsive avec menu mobile
- ✅ Liens vers toutes les sections

### Interactivité
- ✅ Animations hover sur les cartes et boutons
- ✅ Formulaire de contact avec validation
- ✅ Toasts de confirmation (Sonner)
- ✅ Transitions fluides entre sections

### Design Responsif
- ✅ Optimisé pour mobile (320px+)
- ✅ Tablette (768px+)
- ✅ Desktop (1024px+)

### Accessibilité
- ✅ Contrastes WCAG AA
- ✅ Navigation au clavier
- ✅ Sémantique HTML
- ✅ Labels sur tous les formulaires

## 🛠️ Technologies Utilisées

### Frontend
- **React 19** - Framework JavaScript
- **React Router DOM** - Navigation
- **React Scroll** - Smooth scrolling
- **Tailwind CSS** - Styling utilitaire
- **Shadcn UI** - Composants UI
- **Lucide React** - Icônes
- **Sonner** - Toasts

### Backend (Préparé pour l'intégration)
- **FastAPI** - Framework Python
- **MongoDB** - Base de données
- **Motor** - Driver MongoDB async

## 📁 Structure des Fichiers

```
/app/frontend/src/
├── App.js                      # Point d'entrée principal
├── App.css                     # Styles globaux et variables CSS
├── components/
│   ├── Header.jsx              # Navigation fixe
│   ├── Hero.jsx                # Section héro
│   ├── About.jsx               # À propos
│   ├── Menu.jsx                # Menu du restaurant
│   ├── Solidarity.jsx          # Action solidaire
│   ├── Gallery.jsx             # Galerie photos
│   ├── Contact.jsx             # Contact et formulaire
│   └── Footer.jsx              # Pied de page
└── components/ui/              # Composants Shadcn UI
```

## 🚀 État Actuel

### ✅ Terminé (Frontend)
- Design complet et responsive
- Toutes les sections implémentées
- Navigation fonctionnelle
- Formulaire de contact avec mock data
- Images réelles du restaurant intégrées
- Animations et interactions
- Google Maps intégré

### 🔜 Prochaines Étapes (Backend)
- Créer l'API backend pour le formulaire de contact
- Envoyer des emails via le formulaire
- Système de réservation (optionnel)
- Dashboard admin pour gérer le menu (optionnel)

## 📝 Contenu

### Plats au Menu
1. **Entrées**: Salade Fraîche (5€)
2. **Plats principaux**: 
   - Thieb Bou Dieune (8€)
   - Mafé (8€)
   - Poulet Braisé (9€)
   - Attiéké (8€)
   - Crevettes Grillées (9€)
3. **Accompagnements**: Aloko (6€)
4. **Desserts**: Pastèque (3€)

### Services
- Vente à emporter
- Repas sur place
- Accessible en fauteuil roulant
- Options halal, végétarien, végétalien

## 🎯 Objectifs du Site

1. **Présenter** le restaurant et sa mission solidaire
2. **Attirer** des clients locaux (Rennes)
3. **Informer** sur les prix solidaires et l'accessibilité
4. **Engager** la communauté dans l'action solidaire
5. **Faciliter** le contact et l'information pratique

## 🌐 SEO & Visibilité

- Mots-clés: "restaurant solidaire Rennes", "cuisine africaine Rennes", "prix libre Rennes"
- Structure sémantique HTML5
- Meta descriptions (à ajouter)
- Optimisation images
- Google Maps intégré

## 📱 Responsive Design

- **Mobile First**: Design optimisé pour mobile en priorité
- **Breakpoints**:
  - Mobile: 320px - 767px
  - Tablette: 768px - 1023px
  - Desktop: 1024px+

## 🎨 Principes de Design Suivis

1. **Ambiance chaleureuse**: Couleurs naturelles et accueillantes
2. **Clarté**: Information facilement accessible
3. **Solidarité**: Message fort et visible
4. **Professionnalisme**: Design moderne et soigné
5. **Accessibilité**: Ouvert à tous, design inclusif

## 📞 Contact du Restaurant

- **Adresse**: 12 Rue de l'Alma, 35000 Rennes, France
- **Téléphone**: 09 55 40 42 68
- **Horaires**:
  - Lundi - Samedi: 12h00-14h45, 18h00-22h00
  - Dimanche: 12h00-20h00

---

**Site créé avec ❤️ pour AKADY Restaurant Solidaire**
